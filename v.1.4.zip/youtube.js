console.log("youtube is prohibited !");

 const path = window.location.pathname;

 const search  = window.location.search;

window.location = "https://hooktube.com"+ path + search;


